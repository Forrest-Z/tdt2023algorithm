from launch.actions import ExecuteProcess

import os
from ament_index_python.packages import get_package_share_directory
from launch import LaunchDescription
from launch_ros.actions import Node
import launch
import yaml
from launch_ros.substitutions import FindPackageShare

################### user configure parameters for ros2 start ###################

################### user configure parameters for ros2 end #####################


feature_extract_enable = 0
point_filter_num = 1
max_iteration = 3
# scan_publish_enable = 1
dense_publish_enable = 1
filter_size_surf = 0.1
filter_size_map = 0.1
cube_side_length = 1000
runtime_pos_log_enable = 1

yaml_config_path = '/config/mid360.yaml'
fast_lio_slam_param = [
    
    {'feature_extract_enable': bool(feature_extract_enable)},
    {'point_filter_num': point_filter_num},
    {'max_iteration': max_iteration},
    # {'scan_publish_enable': scan_publish_enable},
    {'dense_publish_enable': dense_publish_enable},
    {'filter_size_surf': filter_size_surf},
    {'filter_size_map': filter_size_map},
    {'cube_side_length': float(cube_side_length)},
    {'runtime_pos_log_enable': bool(runtime_pos_log_enable)},

    {'yaml_config':yaml_config_path},
]

pkg_share = FindPackageShare(package='fast_lio_slam').find('fast_lio_slam') 
pkg_path = os.path.join(pkg_share, '../../../../src/robot_localization/fast_lio_slam')
YamlPath = pkg_path+'/config/mid360.yaml'
print(YamlPath)

with open(YamlPath, 'r') as stream:
    try:
        # 加载YAML数据
        config_data = yaml.safe_load(stream)
        # 使用config_data进行操作
        # 访问配置项
        lid_topic = config_data["common"]["lid_topic"]
        imu_topic = config_data["common"]["imu_topic"]
        time_sync_en = config_data["common"]["time_sync_en"]
        lidar_type = config_data["preprocess"]["lidar_type"]
        scan_line = config_data["preprocess"]["scan_line"]
        blind = config_data["preprocess"]["blind"]
        
        acc_cov = config_data["mapping"]["acc_cov"]
        gyr_cov = config_data["mapping"]["gyr_cov"]
        b_acc_cov = config_data["mapping"]["b_acc_cov"]
        b_gyr_cov = config_data["mapping"]["b_gyr_cov"]
        fov_degree = config_data["mapping"]["fov_degree"]
        det_range = config_data["mapping"]["det_range"]
        extrinsic_T = config_data["mapping"]["extrinsic_T"]
        extrinsic_R = config_data["mapping"]["extrinsic_R"]
        path_en = config_data["publish"]["path_en"]
        scan_publish_en = config_data["publish"]["scan_publish_en"]
        dense_publish_en = config_data["publish"]["dense_publish_en"]
        scan_bodyframe_pub_en = config_data["publish"]["scan_bodyframe_pub_en"]
        pcd_save_en = config_data["pcd_save"]["pcd_save_en"]
        pcd_save_interval = config_data["pcd_save"]["interval"]


    except yaml.YAMLError as exc:
        print(exc)

yaml_param = [
    {'common/lid_topic': lid_topic},
    {'common/imu_topic': imu_topic},
    {'common/time_sync_en': time_sync_en},
    {'preprocess/lidar_type': lidar_type},
    {'preprocess/scan_line': scan_line},
    {'preprocess/blind': float(blind)},
    {'mapping/acc_cov': acc_cov},
    {'mapping/gyr_cov': gyr_cov},
    {'mapping/b_acc_cov': b_acc_cov},
    {'mapping/b_gyr_cov': b_gyr_cov},
    {'mapping/fov_degree':float(fov_degree)},
    {'mapping/det_range': det_range},
    {'mapping/extrinsic_T': extrinsic_T},
    {'mapping/extrinsic_R': extrinsic_R},

    {'publish/path_en':path_en},
    {'publish/scan_publish_en':scan_publish_en},
    {'publish/dense_publish_en': dense_publish_en},
    {'publish/scan_bodyframe_pub_en':scan_bodyframe_pub_en},
    {'pcd_save/pcd_save_en':pcd_save_en},
    {'pcd_save_interval':pcd_save_interval},

]

def generate_launch_description():
        

    fast_lio_slam_node = Node(
        package = 'fast_lio_slam',
        executable = 'fastlio_mapping',
        name = 'laserMapping',
        output = 'screen',emulate_tty=True,
        parameters = fast_lio_slam_param+yaml_param
        )
    start_rviz2_node = Node(
                        package="rviz2",
                        executable="rviz2",
                        name='rviz2',
                        output='screen',emulate_tty=True,
                        arguments=['-d', pkg_path+'/rviz_cfg/lio.rviz']

                     )
    # Load velodyne config file
    # load_velodyne_config_cmd = ExecuteProcess(
    #     cmd=[Command('ros2', 'param', 'load', velodyne_config_file)],
    #     output='screen')

    return LaunchDescription(
        [
          fast_lio_slam_node,
          start_rviz2_node,
          # load_velodyne_config_cmd,
        ]
    )

