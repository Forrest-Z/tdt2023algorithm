#include <chrono>
#include <cmath>
#include <memory>

#include "rclcpp/rclcpp.hpp"
#include "nav_msgs/msg/odometry.hpp"
#include "geometry_msgs/msg/pose.hpp"
#include "geometry_msgs/msg/point.hpp"
#include "geometry_msgs/msg/quaternion.hpp"
#include "tf2/LinearMath/Matrix3x3.h"
#include "tf2/LinearMath/Transform.h"
#include "tf2_ros/transform_broadcaster.h"
#include "tf2_ros/transform_listener.h"
#include "tf2_geometry_msgs/tf2_geometry_msgs.h"

using namespace std::chrono_literals;

class TransformFusion : public rclcpp::Node
{
public:
  TransformFusion()
  : Node("transform_fusion")
  {
    localization_publisher_ = this->create_publisher<nav_msgs::msg::Odometry>("/localization", 1);
    odom_subscriber_ = this->create_subscription<nav_msgs::msg::Odometry>("/Odometry", 1, std::bind(&TransformFusion::saveCurOdom, this, std::placeholders::_1));
    map_to_odom_subscriber_ = this->create_subscription<nav_msgs::msg::Odometry>("/map_to_odom", 1, std::bind(&TransformFusion::saveMapToOdom, this, std::placeholders::_1));
    
    tf_buffer_ = std::make_shared<tf2_ros::Buffer>(this->get_clock());
    tf_listener_ = std::make_shared<tf2_ros::TransformListener>(*tf_buffer_);
    tf_broadcaster_ = std::make_shared<tf2_ros::TransformBroadcaster>(this);

    timer_ = this->create_wall_timer(20ms, std::bind(&TransformFusion::publishTransform, this));
  }

private:
  void saveCurOdom(const nav_msgs::msg::Odometry::SharedPtr msg)
  {
    cur_odom_to_baselink_ = *msg;
  }

  void saveMapToOdom(const nav_msgs::msg::Odometry::SharedPtr msg)
  {
    cur_map_to_odom_ = *msg;
  }

  void publishTransform()
  {
    if (cur_map_to_odom_.header.stamp.sec != 0)
    {
      geometry_msgs::msg::TransformStamped transformStamped;
      transformStamped.header.stamp = this->now();
      transformStamped.header.frame_id = "camera_init";
      transformStamped.child_frame_id = "map";
      transformStamped.transform.translation.x = cur_map_to_odom_.pose.pose.position.x;
      transformStamped.transform.translation.y = cur_map_to_odom_.pose.pose.position.y;
      transformStamped.transform.translation.z = cur_map_to_odom_.pose.pose.position.z;
      transformStamped.transform.rotation = cur_map_to_odom_.pose.pose.orientation;

      tf_broadcaster_->sendTransform(transformStamped);
    }

    if (cur_odom_to_baselink_.header.stamp.sec != 0)
    {
      nav_msgs::msg::Odometry localization;
      localization.header.stamp = cur_odom_to_baselink_.header.stamp;
      localization.header.frame_id = "map";
      localization.child_frame_id = "body";

      tf2::Stamped<tf2::Transform> odom_to_baselink;
      tf2::fromMsg(cur_odom_to_baselink_.pose, odom_to_baselink);
      
      tf2::Stamped<tf2::Transform> map_to_odom;
      tf2::fromMsg(cur_map_to_odom_.pose, map_to_odom);

      tf2::Transform map_to_baselink  = map_to_odom * odom_to_baselink;
      tf2::Stamped<tf2::Transform> stamped_map_to_baselink(map_to_baselink, cur_odom_to_baselink_.header.stamp, "map");
      localization.pose.pose = tf2::toMsg(stamped_map_to_baselink);

      localization.twist = cur_odom_to_baselink_.twist;
      localization_publisher_->publish(localization);
    }

    }
    rclcpp::Publisher<nav_msgs::msg::Odometry>::SharedPtr localization_publisher_;
    rclcpp::Subscription<nav_msgs::msg::Odometry>::SharedPtr odom_subscriber_;
    rclcpp::Subscription<nav_msgs::msg::Odometry>::SharedPtr map_to_odom_subscriber_;
    rclcpp::TimerBase::SharedPtr timer_;

    std::shared_ptr<tf2_ros::Buffer> tf_buffer_;
    std::shared_ptr<tf2_ros::TransformListener> tf_listener_;
    std::shared_ptr<tf2_ros::TransformBroadcaster> tf_broadcaster_;

    nav_msgs::msg::Odometry cur_odom_to_baselink_;
    nav_msgs::msg::Odometry cur_map_to_odom_;
};

int main(int argc, char **argv)
{
rclcpp::init(argc, argv);
auto node = std::make_shared<TransformFusion>();
RCLCPP_INFO(node->get_logger(), "Transform Fusion Node Inited...");
rclcpp::spin(node);
rclcpp::shutdown();
return 0;
}