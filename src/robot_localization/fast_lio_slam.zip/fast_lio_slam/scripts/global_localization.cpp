#include <chrono>
#include <iostream>
#include <memory>
#include <thread>

#include "rclcpp/rclcpp.hpp"
#include "sensor_msgs/msg/point_cloud2.hpp"
#include "sensor_msgs/msg/point_field.hpp"
#include "geometry_msgs/msg/pose_with_covariance_stamped.hpp"
#include "nav_msgs/msg/odometry.hpp"
#include "tf2/LinearMath/Transform.h"
#include "tf2/LinearMath/Matrix3x3.h"
#include "tf2_geometry_msgs/tf2_geometry_msgs.h"
#include "tf2_ros/buffer.h"
#include "tf2_ros/transform_listener.h"
// #include "ros_numpy/ros_numpy.h"
#include "pcl_conversions/pcl_conversions.h"
#include "pcl/point_types.h"
#include "pcl/point_cloud.h"
#include "pcl/filters/voxel_grid.h"
#include "pcl/registration/icp.h"
#include "pcl/registration/icp_nl.h"
#include "pcl/registration/transforms.h"
#include "pcl/filters/passthrough.h"

using std::placeholders::_1;
using std::placeholders::_2;
using std::placeholders::_3;

const float MAP_VOXEL_SIZE = 0.4;
const float SCAN_VOXEL_SIZE = 0.1;
const float FREQ_LOCALIZATION = 0.5;
const float LOCALIZATION_TH = 0.95;
const float FOV = 1.6;
const float FOV_FAR = 150.0;

class FastLioLocalization : public rclcpp::Node
{
public:
    FastLioLocalization()
    : Node("fast_lio_localization"), tf_buffer_(this->get_clock()), tf_listener_(tf_buffer_)
    {
        RCLCPP_INFO(this->get_logger(), "Localization Node Inited...");

        // publisher
        pub_pc_in_map_ = this->create_publisher<sensor_msgs::msg::PointCloud2>("/cur_scan_in_map", 1);
        pub_submap_ = this->create_publisher<sensor_msgs::msg::PointCloud2>("/submap", 1);
        pub_map_to_odom_ = this->create_publisher<nav_msgs::msg::Odometry>("/map_to_odom", 1);

        // subscribers
        sub_cloud_registered_ = this->create_subscription<sensor_msgs::msg::PointCloud2>(
        "/cloud_registered", 1, std::bind(&FastLioLocalization::cb_save_cur_scan, this, _1));
        sub_odom_ = this->create_subscription<nav_msgs::msg::Odometry>(
        "/Odometry", 1, std::bind(&FastLioLocalization::cb_save_cur_odom, this, _1));

        // Wait for the global map and initial pose
        RCLCPP_INFO(this->get_logger(), "Waiting for global map...");
        initialize_global_map(
        *(std::make_shared<sensor_msgs::msg::PointCloud2>(*(rclcpp::spin_until_future_complete(
            sub_map_.get_future(), std::chrono::nanoseconds(-1)).get()))));

        while (!initialized_) 
        {
        RCLCPP_INFO(this->get_logger(), "Waiting for initial pose...");
        // Wait for initial pose
        auto pose_msg = rclcpp::spin_until_future_complete(sub_initialpose_.get_future(), std::chrono::nanoseconds(-1));
        auto initial_pose = pose_to_mat(pose_msg);
        if (cur_scan_) {
            initialized_ = global_localization(initial_pose);
        } else {
            RCLCPP_WARN(this->get_logger(), "First scan not received!");
        }
        }
        // Start the thread for periodic global localization
        localization_thread_ = std::thread(std::bind(&FastLioLocalization::thread_localization, this));
    }
private:
    void initialize_global_map(const sensor_msgs::msg::PointCloud2& pc_msg)
    {
        global_map_ = std::make_shared<pcl::PointCloudpcl::PointXYZ>();
        pcl::fromROSMsg(pc_msg, *global_map_);
        voxel_down_sample(global_map_, MAP_VOXEL_SIZE);
        RCLCPP_INFO(this->get_logger(), "Global map received.");
    }

    void cb_save_cur_odom(const nav_msgs::msg::Odometry::SharedPtr msg)
    {
        cur_odom_ = msg;
    }

    void cb_save_cur_scan(const sensor_msgs::msg::PointCloud2::SharedPtr msg)
    {
        // Convert PointCloud2 to PCL point cloud
        pcl::PointCloudpcl::PointXYZI::Ptr pcl_pc = std::make_shared<pcl::PointCloudpcl::PointXYZI>();
        pcl::fromROSMsg(*msg, *pcl_pc);
        pcl_pc->header.frame_id = "camera_init";
        pcl_pc->header.stamp = pcl_conversions::toPCL(msg->header).stamp;
        pub_pc_in_map_->publish(*msg);
        // Down sample the point cloud
        cur_scan_ = std::make_shared<pcl::PointCloud<pcl::PointXYZI>>();
        voxel_down_sample(pcl_pc, SCAN_VOXEL_SIZE, *cur_scan_);
    }
    bool global_localization(const Eigen::Matrix4f& pose_estimation)
    {
        RCLCPP_INFO(this->get_logger(), "Global localization by scan-to-map matching...");
        // Use ICP to register the scan with the global map
        // Wait for the global map and current scan
        while (!global_map_ || !cur_scan_) 
        {
        std::this_thread::sleep_for(std::chrono::milliseconds(10));
        }
        // Crop global map in FOV
        pcl::PointCloud<pcl::PointXYZ>::Ptr global_map_in_FOV = crop_global_map_in_FOV(global_map_, pose_estimation, cur_odom_);

        // Coarse registration
        pcl::PointCloud<pcl::PointXYZI>::Ptr aligned = std::make_shared<pcl::PointCloud<pcl::PointXYZI>>();
        pcl::IterativeClosestPoint<pcl::PointXYZI, pcl::PointXYZI> icp_coarse;
        icp_coarse.setInputSource(cur_scan_);
        icp_coarse.setInputTarget(global_map_in_FOV);
        icp_coarse.align(*aligned, pose_estimation);
        Eigen::Matrix4f transformation = icp_coarse.getFinalTransformation();

        // Fine registration
        pcl::PointCloud<pcl::PointXYZI>::Ptr aligned_fine = std::make_shared<pcl::PointCloud<pcl::PointXYZI>>();
        pcl::IterativeClosestPointNonLinear<pcl::PointXYZI, pcl::PointXYZI> icp_fine;
        icp_fine.setInputSource(cur_scan_);
        icp_fine.setInputTarget(global_map_in_FOV);
        icp_fine.align(*aligned_fine, transformation);
        float fitness_score = icp_fine.getFitnessScore();
        transformation = icp_fine.getFinalTransformation();

        RCLCPP_INFO(this->get_logger(), "Time: %f", icp_fine.getFinalTransformation());
        RCLCPP_INFO(this->get_logger(), "");

        // Update map to odom transform if the localization succeeded
        if (fitness_score > LOCALIZATION_TH) 
        {
        T_map_to_odom_ = transformation;

        // Publish map to odom transform
        nav_msgs::msg::Odometry map_to_odom;
        map_to_odom.pose.pose = tf2::toMsg(tf2::Transform(tf2::Matrix T_map_to_odom_));
        map_to_odom.header.stamp = cur_odom_->header.stamp;
        map_to_odom.header.frame_id = "map";
        pub_map_to_odom_->publish(map_to_odom);
        return true;
        } else 
        {
        RCLCPP_WARN(this->get_logger(), "Not match!!!!");
        RCLCPP_WARN(this->get_logger(), "%f", transformation);
        RCLCPP_WARN(this->get_logger(), "fitness score: %f", fitness_score);
        return false;
        }

    }

    pcl::PointCloudpcl::PointXYZ::Ptr crop_global_map_in_FOV(pcl::PointCloudpcl::PointXYZ::Ptr global_map,
    const Eigen::Matrix4f& pose_estimation,
    const nav_msgs::msg::Odometry::SharedPtr cur_odom)
    {
        // Get current scan origin pose in the odom frame
        Eigen::Matrix4f T_odom_to_base_link = Eigen::Matrix4f::Identity();
        T_odom_to_base_link.block<3, 3>(0, 0) = Eigen::Quaternionf(cur_odom->pose.pose.orientation.w,
        cur_odom->pose.pose.orientation.x,
        cur_odom->pose.pose.orientation.y,
        cur_odom->pose.pose.orientation.z).toRotationMatrix();
        T_odom_to_base_link.block<3, 1>(0, 3) = Eigen::Vector3f(cur_odom->pose.pose.position.x,
        cur_odom->pose.pose.position.y,
        cur_odom->pose.pose.position.z);
        // Transform the global map to the lidar frame
        pcl::PointCloud<pcl::PointXYZ>::Ptr global_map_in_base_link = std::make_shared<pcl::PointCloud<pcl::PointXYZ>>();
        pcl::transformPointCloud(*global_map, *global_map_in_base_link, pose_estimation * T_odom_to_base_link);

        // Extract the points within the FOV
        pcl::PointCloud<pcl::PointXYZ>::Ptr global_map_in_FOV = std::make_shared<pcl::PointCloud<pcl::PointXYZ>>();
        for (const auto& pt : global_map_in_base_link->points) {
        float range = std::sqrt(pt.x * pt.x + pt.y * pt.y + pt.z * pt.z);
        if (range < FOV_FAR && std::abs(std::atan2(pt.y, pt.x)) < FOV / 2.0) {
            global_map_in_FOV->points.push_back(pt);
        }
        }

        // Publish point cloud within FOV
        if (global_map_in_FOV->size() > 0) {
        sensor_msgs::msg::PointCloud2 pc2;
        pcl::toROSMsg(*global_map_in_FOV, pc2);
        pc2.header = cur_odom_->header;
        pc2.header.frame_id = "map";
        pub_submap_->publish(pc2);
        }

        return global_map_in_FOV;
    }
    void voxel_down_sample(pcl::PointCloudpcl::PointXYZ::Ptr cloud, float voxel_size)
    {
        pcl::VoxelGridpcl::PointXYZ sor;
        sor.setInputCloud(cloud);
        sor.setLeafSize(voxel_size, voxel_size, voxel_size);
        sor.filter(*cloud);
    }

    void voxel_down_sample(pcl::PointCloudpcl::PointXYZI::Ptr cloud, float voxel_size, pcl::PointCloudpcl::PointXYZI& output)
    {
        pcl::VoxelGridpcl::PointXYZI sor;
        sor.setInputCloud(cloud);
        sor.setLeafSize(voxel_size, voxel_size, voxel_size);
        sor.filter(output);
    }
    void thread_localization()
    {
        while (rclcpp::ok()) 
        {
                // Perform global localization every FREQ_LOCALIZATION seconds
            std::this_thread::sleep_for(std::chrono::milliseconds(1000 / FREQ_LOCALIZATION));
            if (!cur_scan_) 
            {
                RCLCPP_WARN(this->get_logger(), "No scan received yet!");
                continue;
            }

            // Use current map-to-odom as the initial guess for ICP
            Eigen::Matrix4f pose_estimation = T_map_to_odom_;

            // Global localization by scan-to-map matching
            RCLCPP_INFO(this->get_logger(), "Global localization by scan-to-map matching......");

            pcl::PointCloud<pcl::PointXYZ>::Ptr scan_tobe_mapped(new pcl::PointCloud<pcl::PointXYZ>);
            *scan_tobe_mapped = *cur_scan_;

            auto global_map_in_FOV = crop_global_map_in_FOV(global_map_, pose_estimation, cur_odom_);

            // Coarse ICP
            Eigen::Matrix4f transformation;
            float fitness_score;
            std::tie(transformation, fitness_score) =
                registration_at_scale(scan_tobe_mapped, global_map_in_FOV, pose_estimation, 5);

            // Fine ICP
            std::tie(transformation, fitness_score) =
                registration_at_scale(scan_tobe_mapped, global_map_in_FOV, transformation, 1);

            RCLCPP_INFO(this->get_logger(), "Time: %f", (std::chrono::system_clock::now() - start).count() / 1e9);

            // Update map-to-odom when global localization succeeds
            if (fitness_score > LOCALIZATION_TH) 
            {
                T_map_to_odom_ = transformation;
                RCLCPP_INFO(this->get_logger(), "Global localization succeeded!!!!!!");

                // Publish map-to-odom transform
                nav_msgs::msg::Odometry map_to_odom;
                Eigen::Vector3f xyz = T_map_to_odom_.block<3, 1>(0, 3);
                Eigen::Quaternionf quat(T_map_to_odom_.block<3, 3>(0, 0));
                map_to_odom.pose.pose.position.x = xyz.x();
                map_to_odom.pose.pose.position.y = xyz.y();
                map_to_odom.pose.pose.position.z = xyz.z();
                map_to_odom.pose.pose.orientation.x = quat.x();
                map_to_odom.pose.pose.orientation.y = quat.y();
                map_to_odom.pose.pose.orientation.z = quat.z();
                map_to_odom.pose.pose.orientation.w = quat.w();
                map_to_odom.header.stamp = cur_odom_->header.stamp;
                map_to_odom.header.frame_id = "map";
                pub_map_to_odom_->publish(map_to_odom);
            } else 
            {
                RCLCPP_WARN(this->get_logger(), "Not match!!!!");
                RCLCPP_WARN(this->get_logger(), "%f", transformation);
                RCLCPP_WARN(this->get_logger(), "fitness score: %f", fitness_score);
            }
        }
    }
    void cb_global_map(const sensor_msgs::msg::PointCloud2::SharedPtr msg)
    {
        global_map_.reset(new pcl::PointCloudpcl::PointXYZ);
        pcl::fromROSMsg(*msg, *global_map_);
        voxel_down_sample(global_map_, MAP_VOXEL_SIZE);
        RCLCPP_INFO(this->get_logger(), "Global map received.");
    }

    void cb_save_cur_odom(const nav_msgs::msg::Odometry::SharedPtr msg)
    {
        cur_odom_ = msg;
    }

    void cb_save_cur_scan(const sensor_msgs::msg::PointCloud2::SharedPtr msg)
    {
        // Transform the scan to the odom frame
        // pcl::PointCloudpcl::PointXYZI::Ptr
        pcl::PointCloud<pcl::PointXYZI>::Ptr cur_scan_raw(new pcl::PointCloud<pcl::PointXYZI>);
        pcl::fromROSMsg(*msg, *cur_scan_raw);

        pcl::PointCloud<pcl::PointXYZ>::Ptr cur_scan(new pcl::PointCloud<pcl::PointXYZ>);
        for (auto& p : cur_scan_raw->points) 
        {
            if (std::isnan(p.x) || std::isnan(p.y) || std::isnan(p.z)) 
            {
                continue;
            }
            cur_scan->push_back(pcl::PointXYZ(p.x, p.y, p.z));
        }

        // Publish the scan in the map frame
        cur_scan->header.frame_id = "camera_init";
        cur_scan->header.stamp = rclcpp::Time::now().toNSec() / 1000;
        pub_pc_in_map_->publish(cur_scan);

        cur_scan_ = cur_scan;
    }

    rclcpp::Node::SharedPtr nh_;

    // Parameters
    float MAP_VOXEL_SIZE;
    float SCAN_VOXEL_SIZE;
    float FREQ_LOCALIZATION;
    float LOCALIZATION_TH;
    float FOV;
    float FOV_FAR;

    // Subscribers
    rclcpp::Subscription<sensor_msgs::msg::PointCloud2>::SharedPtr sub_global_map_;
    rclcpp::Subscription<nav_msgs::msg::Odometry>::SharedPtr sub_cur_odom_;
    rclcpp::Subscription<sensor_msgs::msg::PointCloud2>::SharedPtr sub_cur_scan_;

    // Publishers
    rclcpp::Publisher<sensor_msgs::msg::PointCloud2>::SharedPtr pub_pc_in_map_;
    rclcpp::Publisher<sensor_msgs::msg::PointCloud2>::SharedPtr pub_submap_;
    rclcpp::Publisher<nav_msgs::msg::Odometry>::SharedPtr pub_map_to_odom_;

    // Global map and current scan
    pcl::PointCloudpcl::PointXYZ::Ptr global_map_;
    pcl::PointCloudpcl::PointXYZ::Ptr cur_scan_;
    nav_msgs::msg::Odometry::SharedPtr cur_odom_;

    // Transform from map to odom
    Eigen::Matrix4f T_map_to_odom_;
};


int main(int argc, char** argv)
{
    rclcpp::init(argc, argv);
    rclcpp::spin(std::make_shared<FastLioLocalization>());
    rclcpp::shutdown();
    return 0;
}

