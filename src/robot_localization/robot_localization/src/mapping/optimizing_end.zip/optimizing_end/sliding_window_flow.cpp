/*
 * @Description: lio localization backend workflow, implementation
 */
// #include "../../../include/mapping/optimizing_end/sliding_window_flow.hpp"
#include "robot_localization/mapping/optimizing_end/sliding_window_flow.hpp"

// #include "glog/logging.h"

// #include "../../../include/tools/file_manager.hpp"

namespace robot_localization {

SlidingWindowFlow::SlidingWindowFlow(std::shared_ptr<rclcpp::Node>& node_) 
{
    YAML::Node user_config = YAML::LoadFile(WORK_PACKAGE_PATH + "/config/user_setting.yaml");
    // 配置用户设置消息话题
    std::string imu_raw_data_topic="";
    std::string lidar_link;
    std::string car_base_link;
    std::string global_frame_id;
    std::string environment = "_"+user_config["work_environment"].as<std::string>();


    if_sliding_window_tf_broadcast = false;
    if (user_config["optimizing_end_send_tf"].as<bool>())
        if_sliding_window_tf_broadcast = true;

    imu_raw_data_topic =  user_config["imu"+environment].as<std::string>();
    lidar_link = user_config["lidar_link"+environment].as<std::string>();
    car_base_link = user_config["car_base_link"+environment].as<std::string>();
    global_frame_id = user_config["global_frame_id"+environment].as<std::string>();//默认是odom

    // 优化端需要接收:
    // a. lidar odometry 激光雷达（紧耦合imu）里程计:
    laser_odom_sub_ptr_ = std::make_shared<OdometrySubscriber>(node_, "/fused_odom", 100000);
    // b. map matching odometry 来自图匹配端的位姿:
    map_matching_odom_sub_ptr_ = std::make_shared<OdometrySubscriber>(node_, "/map_matching_odom", 100000);
    // c. IMU measurement, for pre-integration:
    imu_raw_sub_ptr_ = std::make_shared<ImuSubscriber>(node_, imu_raw_data_topic, 1000000);
    imu_synced_sub_ptr_ = std::make_shared<ImuSubscriber>(node_, "/synced_imu", 100000);
    

    //  优化端发布:
    // a. current lidar key frame:
    // key_frame_pub_ptr_ = std::make_shared<KeyFramePublisher>(node_, "/key_frame", global_frame_id, 100);
    // b. optimized odometry 最终优化位姿:
    optimized_odom_pub_ptr_ = std::make_shared<OdometryPublisher>(node_, "/optimized_odom", global_frame_id, "lidar", 100);
    // c. optimized trajectory:
    // optimized_trajectory_pub_ptr_ = std::make_shared<KeyFramesPublisher>(node_, "/optimized_trajectory", global_frame_id, 100);
    // d. lidar frame
    laser_tf_pub_ptr_ = std::make_shared<TFBroadcaster>(node_,global_frame_id, car_base_link);

    // 优化端任务管理器:
    sliding_window_ptr_ = std::make_shared<SlidingWindow>();
}

bool SlidingWindowFlow::Run() 
{
    if ( !ReadData() )
        return false;
    
    while( HasData() ) 
    {
        // 确保所有的测量数据是同步的:
        if ( !ValidData() )
            continue;
        green_info("begin sliding_window_optimizing");
        sliding_window_optimizing();
        green_info("to publish optimized pose");

        PublishData();
    }

    return true;
}

bool SlidingWindowFlow::Run0220() 
{
    if ( !ReadData() )
        return false;
    while( HasData0220() ) 
    {
        // 确保所有的测量数据是同步的:
        if ( !ValidData0220() )
            continue;


        PublishData();
    }


}



bool SlidingWindowFlow::SaveOptimizedTrajectory() 
{
    sliding_window_ptr_ -> SaveOptimizedTrajectory();

    return true;
}

bool SlidingWindowFlow::ReadData() 
{
    // a. 里程计端的位姿:
    laser_odom_sub_ptr_->ParseData(laser_odom_data_buff_);
    // b. 点云图匹配算出位姿:
    map_matching_odom_sub_ptr_->ParseData(map_matching_odom_data_buff_);
    // c. IMU测量数据，用于预计分:
    imu_raw_sub_ptr_->ParseData(imu_raw_data_buff_);
    imu_synced_sub_ptr_->ParseData(imu_synced_data_buff_);
    

    return true;
}

bool SlidingWindowFlow::HasData() 
{   
    if (
        laser_odom_data_buff_.empty() ||
        map_matching_odom_data_buff_.empty() ||
        imu_synced_data_buff_.empty()
        ) 
    {
        return false;
    }

    
    return true;
}


bool SlidingWindowFlow::HasData0220() 
{
    if (laser_odom_data_buff_.empty() ||imu_synced_data_buff_.empty()) 
    {
        return false;
    }

    if(map_matching_odom_data_buff_.empty())
    {
        matching_pose_empty = true;
    }

    return true;
}

bool SlidingWindowFlow::ValidData() 
{
    current_laser_odom_data_ = laser_odom_data_buff_.front();
    current_map_matching_odom_data_ = map_matching_odom_data_buff_.front();
    current_imu_data_ = imu_synced_data_buff_.front();

    double diff_map_matching_odom_time = current_laser_odom_data_.time - current_map_matching_odom_data_.time;
    double diff_imu_time = current_laser_odom_data_.time - current_imu_data_.time_stamp_;

    if ( diff_map_matching_odom_time < -0.05 || diff_imu_time < -0.05 ) 
    {
        laser_odom_data_buff_.pop_front();
        return false;
    }

    if ( diff_map_matching_odom_time > 0.05 ) 
    {
        map_matching_odom_data_buff_.pop_front();
        return false;
    }

    if ( diff_imu_time > 0.05 ) 
    {
        imu_synced_data_buff_.pop_front();
        return false;
    }


    laser_odom_data_buff_.pop_front();
    map_matching_odom_data_buff_.pop_front();
    imu_synced_data_buff_.pop_front();

    return true;
}

bool SlidingWindowFlow::ValidData0220() 
{
    current_laser_odom_data_ = laser_odom_data_buff_.front();
    current_map_matching_odom_data_ = map_matching_odom_data_buff_.front();
    current_imu_data_ = imu_synced_data_buff_.front();

    double diff_map_matching_odom_time = current_laser_odom_data_.time - current_map_matching_odom_data_.time;
    double diff_imu_time = current_laser_odom_data_.time - current_imu_data_.time_stamp_;

    if ( diff_map_matching_odom_time < -0.05 || diff_imu_time < -0.05 ) 
    {
        laser_odom_data_buff_.pop_front();
        return false;
    }

    if ( diff_map_matching_odom_time > 0.05 ) 
    {
        map_matching_odom_data_buff_.pop_front();
        return false;
    }

    if ( diff_imu_time > 0.05 ) 
    {
        imu_synced_data_buff_.pop_front();
        return false;
    }


    laser_odom_data_buff_.pop_front();
    map_matching_odom_data_buff_.pop_front();
    imu_synced_data_buff_.pop_front();

    return true;
}

/**
 * @brief 更新IMU预积分
 * @note  取走的是imu_raw_data_buf中的第一个
 * @param imu_raw_data_buff_.front()
 **/
bool SlidingWindowFlow::UpdateIMUPreIntegration(void) 
{
    while (!imu_raw_data_buff_.empty() && 
            imu_raw_data_buff_.front().time_stamp_ < current_imu_data_.time_stamp_ && 
            sliding_window_ptr_->UpdateIMUPreIntegration(imu_raw_data_buff_.front())) 
    {
        imu_raw_data_buff_.pop_front();
    }

    return true;
}

bool SlidingWindowFlow::sliding_window_optimizing()
{
    static bool odometry_inited = false;
    static Eigen::Matrix4f odom_init_pose = Eigen::Matrix4f::Identity();

    if ( !odometry_inited ) 
    {
        // 地图帧中激光雷达里程计测量帧的到这里的第一次原点为初始姿态:
        // odom_init_pose = current_gnss_pose_data_.pose * current_laser_odom_data_.pose.inverse();
        odom_init_pose = current_laser_odom_data_.pose;
        // odom_init_pose = Eigen::Matrix4f::Identity();
        odometry_inited = true;
    }
    
    // update IMU pre-integration 更新imu预积分:
    green_info("begin update IMU pre-integration");
    UpdateIMUPreIntegration();
    
    // current lidar odometry in map frame:
    current_laser_odom_data_.pose = odom_init_pose * current_laser_odom_data_.pose;

    // optimization is carried out in map frame:
    return sliding_window_ptr_->Update(
                                        current_laser_odom_data_, 
                                        current_map_matching_odom_data_,
                                        current_imu_data_
                                        );
}


bool SlidingWindowFlow::PublishData() 
{
    if ( sliding_window_ptr_->HasNewKeyFrame() ) 
    {        
        KeyFrame key_frame;

        sliding_window_ptr_->GetLatestKeyFrame(key_frame);
        // key_frame_pub_ptr_->Publish(key_frame);

    }

    if ( sliding_window_ptr_->HasNewOptimized() ) 
    {   
        cyan_info("Has New Optimized");// 帧率落后的原因验证
        KeyFrame key_frame;
        sliding_window_ptr_->GetLatestOptimizedOdometry(key_frame);
        optimized_odom_pub_ptr_->Publish(key_frame.pose.cast<double>(), key_frame.time);

        // publish lidar TF:
        if(if_sliding_window_tf_broadcast)
            laser_tf_pub_ptr_->SendTransform(key_frame.pose.cast<double>(), key_frame.time);
    }

    return true;
}

bool SlidingWindowFlow::accumulation_error_optimizing()
{
    //用于储存里程计累积带来的位置与姿态的累积误差，具体的实现是 odom - matching_pose
    // static Eigen::Matrix4d odom_accumulation_error = Eigen::Matrix4d::Identity();
    static nav_msgs::msg::Odometry odom_accumulation_error;
    static bool odometry_inited = false;
    static Eigen::Matrix4f odom_init_pose = Eigen::Matrix4f::Identity();

    if ( !odometry_inited ) 
    {
        // 地图帧中激光雷达里程计测量帧的到这里的第一次原点为初始姿态:
        odom_init_pose = current_laser_odom_data_.pose;
        // odom_init_pose = current_map_matching_odom_data_.pose;
        // odom_init_pose = Eigen::Matrix4f::Identity();
        odometry_inited = true;
    }
    
    // current lidar odometry in map frame:
    current_laser_odom_data_.pose = odom_init_pose * current_laser_odom_data_.pose;

    // optimization is carried out in map frame:
    return sliding_window_ptr_->Update(
                                        current_laser_odom_data_, 
                                        current_map_matching_odom_data_,
                                        current_imu_data_
                                        );


    // if()
}

bool SlidingWindowFlow::PublishData0220() 
{

    optimized_odom_pub_ptr_->Publish(optimized_odom);

    optimized_pose(0,3) = optimized_odom.pose.pose.position.x;
    optimized_pose(1,3) = optimized_odom.pose.pose.position.y;
    optimized_pose(2,3) = optimized_odom.pose.pose.position.z;
    Eigen::Quaterniond q;
    q.x() = optimized_odom.pose.pose.orientation.x;
    q.y() = optimized_odom.pose.pose.orientation.y;
    q.z() = optimized_odom.pose.pose.orientation.z;
    q.w() = optimized_odom.pose.pose.orientation.w;
    optimized_pose.block<3,3>(0,0) = q.matrix();

    // publish lidar TF:
    if(if_sliding_window_tf_broadcast)
        laser_tf_pub_ptr_->SendTransform(optimized_pose, optimized_odom.header.stamp);
    

    return true;
}

} // namespace robot_localization