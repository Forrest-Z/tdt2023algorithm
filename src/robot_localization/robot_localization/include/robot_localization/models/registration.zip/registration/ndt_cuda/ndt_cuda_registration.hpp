#ifndef REGISTRATION_NDT_CUDA_REGISTRATION_HPP_
#define REGISTRATION_NDT_CUDA_REGISTRATION_HPP_

#include "../registration_interface.hpp"
#include "cudaNDT.h"
#include <pcl/io/pcd_io.h>
#include <pcl/registration/ndt.h>


namespace robot_localization
{

  class NDTCUDARegistration : public RegistrationInterface// 继承点云配准的基类
  { 
  public:
    NDTCUDARegistration(const YAML::Node &node) :input_target_pc( new pcl::PointCloud<pcl::PointXYZ>())
    {   
        // input_target_pc.reset( new pcl::PointCloud<pcl::PointXYZ>());
        NDTCUDARegistration::resolution = node["res"].as<float>();
        NDTCUDARegistration::step_size = node["step_size"].as<float>();
        NDTCUDARegistration::transformation_epsilon = node["trans_eps"].as<float>();
        NDTCUDARegistration::maximum_iterations = node["max_iter"].as<int>();
    }

    inline bool SetInputTarget(const CloudData::CLOUD_PTR &input_target) override;
    

    bool ScanMatch(const CloudData::CLOUD_PTR &input_source,
                   const Eigen::Matrix4d &predict_pose,
                   CloudData::CLOUD_PTR &result_cloud_ptr,
                   Eigen::Matrix4d &result_pose) override
    {
      ;
    }
    float GetFitnessScore() override
    {
      ;
    }
    inline bool ScanMatch(
                    const pcl::PointCloud<pcl::PointXYZ>::Ptr &input_source,
                    const Eigen::Matrix4d &guess_pose,
                    pcl::PointCloud<pcl::PointXYZ>::Ptr &result_cloud_ptr,
                    Eigen::Matrix4d &result_pose,
                    float &fitness_score
                   ) override;  
    inline double calculateFitneeScore(pcl::PointCloud<pcl::PointXYZ>::Ptr P,
        pcl::PointCloud<pcl::PointXYZ>::Ptr Q,
        Eigen::Matrix4f transformation_matrix);
        
  public:
    float resolution = 1.0;//设置NDT算法中用于计算高斯核的分辨率
    int maximum_iterations = 72;//设置NDT算法的最大迭代次数
    float transformation_epsilon = 0.01;//NDT算法中的变换矩阵阈值 (迭代过程中，当变换矩阵的变化量小于该阈值时，算法停止迭代）
    float step_size = 0.1;//设置NDT算法中的步长大小
    pcl::PointCloud<pcl::PointXYZ>::Ptr input_target_pc;
    // inline bool SetRegistrationParam(float res, float step_size, float trans_eps, int max_iter);
    
  };

  bool NDTCUDARegistration::SetInputTarget(const CloudData::CLOUD_PTR &input_target)
  { 
    // input_target_pc.reset (new pcl::PointCloud<pcl::PointXYZ>(*input_target));
    pcl::copyPointCloud(*input_target, *input_target_pc);
    // input_target_pc = input_target;

    return true;
  }

  bool NDTCUDARegistration::ScanMatch(
                                      const pcl::PointCloud<pcl::PointXYZ>::Ptr &input_source,
                                      const Eigen::Matrix4d &guess_pose,
                                      pcl::PointCloud<pcl::PointXYZ>::Ptr &result_cloud_ptr,
                                      Eigen::Matrix4d &result_pose,
                                      float &fitness_score
                                     )
  {
    {
      pcl::PointCloud<pcl::PointXYZRGB>::Ptr cloudALL (new pcl::PointCloud<pcl::PointXYZRGB>(input_source->size() + input_target_pc->size(),1));
      for (int i = 0; i < input_source->size(); i++)
      {
        pcl::PointXYZRGB pointin;
        pointin.x = (*input_source)[i].x;
        pointin.y = (*input_source)[i].y;
        pointin.z = (*input_source)[i].z;
        pointin.r = 255;
        pointin.g = 0;
        pointin.b = 0;
        (*cloudALL)[i] = pointin;
      }
      for (int i = 0; i < input_target_pc->size(); i++)
      {
        pcl::PointXYZRGB pointout;
        pointout.x = (*input_target_pc)[i].x;
        pointout.y = (*input_target_pc)[i].y;
        pointout.z = (*input_target_pc)[i].z;
        pointout.r = 0;
        pointout.g = 255;
        pointout.b = 255;
        (*cloudALL)[i+input_source->size()] = pointout;
      }

      // pcl::io::savePCDFile<pcl::PointXYZRGB> ("basic.pcd", *cloudALL);
    }

    int nP = input_source->size();
    // int nQ = result_cloud_ptr->size();
    int nQ = input_target_pc->size();
    // std::cout << "input_target_pc size "<<nQ<< std::endl;
    float *nPdata = (float *)input_source->points.data();
    // float *nQdata = (float *)result_cloud_ptr->points.data();
    float *nQdata = (float *)input_target_pc->points.data();

    std::chrono::steady_clock::time_point t1 = std::chrono::steady_clock::now();
    std::chrono::steady_clock::time_point t2 = std::chrono::steady_clock::now();
    std::chrono::duration<double, std::ratio<1, 1000>> time_span =
    std::chrono::duration_cast<std::chrono::duration<double, std::ratio<1, 1000>>>(t2 - t1);

    Eigen::Matrix4f matrix_trans = Eigen::Matrix4f::Identity();
    
    Eigen::Matrix4f init_guess = matrix_trans;//guess_pose.cast<float>();
    printf("guess_pose Rotation matrix :\n");
    printf("    | %f %f %f | \n", init_guess(0, 0), guess_pose(0, 1), guess_pose(0, 2));
    printf("R = | %f %f %f | \n", init_guess(1, 0), guess_pose(1, 1), guess_pose(1, 2));
    printf("    | %f %f %f | \n", guess_pose(2, 0), guess_pose(2, 1), guess_pose(2, 2));
    printf("guess_pose Translation vector :\n");
    printf("t = < %f, %f, %f >\n\n", guess_pose(0, 3), guess_pose(1, 3), guess_pose(2, 3));
    std::cout << "------------checking CUDA NDT(GPU)---------------- "<< std::endl;
    /************************************************/
    cudaStream_t stream = NULL;
    cudaStreamCreate ( &stream );

    float *PUVM = NULL;
    cudaMallocManaged(&PUVM, sizeof(float) * 4 * nP, cudaMemAttachHost);
    cudaStreamAttachMemAsync (stream, PUVM );
    cudaMemcpyAsync(PUVM, nPdata, sizeof(float) * 4 * nP, cudaMemcpyHostToDevice, stream);

    float *QUVM = NULL;
    cudaMallocManaged(&QUVM, sizeof(float) * 4 * nQ, cudaMemAttachHost);
    cudaStreamAttachMemAsync (stream, QUVM );
    cudaMemcpyAsync(QUVM, nQdata, sizeof(float) * 4 * nQ, cudaMemcpyHostToDevice, stream);

    float *guess = NULL;
    cudaMallocManaged(&guess, sizeof(float) * 4 * 4, cudaMemAttachHost);
    cudaStreamAttachMemAsync (stream, guess);
    cudaMemcpyAsync(guess, init_guess.data(), sizeof(float) * 4 * 4, cudaMemcpyHostToDevice, stream);

    float *cudaMatrix = NULL;
    cudaMallocManaged(&cudaMatrix, sizeof(float) * 4 * 4, cudaMemAttachHost);
    cudaStreamAttachMemAsync (stream, cudaMatrix);
    cudaMemsetAsync(cudaMatrix, 0, sizeof(float) * 4 * 4, stream);

    cudaStreamSynchronize(stream);

    cudaNDT ndtTest(nP, nQ, stream);

    ndtTest.setInputSource ((void*)PUVM);
    ndtTest.setInputTarget ((void*)QUVM);
    ndtTest.setResolution (1.0);  //设置NDT算法中用于计算高斯核的分辨率
    ndtTest.setMaximumIterations (35);  //设置NDT算法的最大迭代次数
    ndtTest.setTransformationEpsilon (0.01);  //设置NDT算法中的变换矩阵阈值 (即在迭代过程中，当变换矩阵的变化量小于该阈值时，算法停止迭代）
    ndtTest.setStepSize (0.1);  //设置NDT算法中的步长大小

    t1 = std::chrono::steady_clock::now();
    ndtTest.ndt((float*)PUVM, nP, (float*)QUVM, nQ, guess, cudaMatrix, stream);
    //调用ndtTest.ndt()函数时，将初始猜测矩阵init_guess作为输入参数传递，然后在函数内部计算出匹配的变换矩阵，将其保存在cudaMatrix

    t2 = std::chrono::steady_clock::now();
    time_span = std::chrono::duration_cast<std::chrono::duration<double, std::ratio<1, 1000>>>(t2 - t1);
    std::cout << "CUDA NDT by Time: " << time_span.count() << " ms."<< std::endl;
    cudaStreamDestroy(stream);
    /************************************************/
    memcpy(matrix_trans.data(), cudaMatrix, sizeof(float)*4*4);//通过memcpy函数将cudaMatrix中的值复制到matrix_trans
    // transformation_matrix = matrix_trans;//最后将matrix_trans赋值给传递进来的transformation_matrix
    // result_pose = matrix_trans.cast<double>();

    memcpy(result_pose.data(), cudaMatrix, sizeof(double)*4*4);//通过memcpy函数将cudaMatrix中的值复制到matrix_trans

    // std::cout << "CUDA NDT fitness_score: " << calculateFitneeScore (input_source, input_target_pc, matrix_trans) << std::endl;
    // print4x4Matrix (matrix_trans);
    printf("Rotation matrix :\n");
    printf("    | %f %f %f | \n", matrix_trans(0, 0), matrix_trans(0, 1), matrix_trans(0, 2));
    printf("R = | %f %f %f | \n", matrix_trans(1, 0), matrix_trans(1, 1), matrix_trans(1, 2));
    printf("    | %f %f %f | \n", matrix_trans(2, 0), matrix_trans(2, 1), matrix_trans(2, 2));
    printf("Translation vector :\n");
    printf("t = < %f, %f, %f >\n\n", matrix_trans(0, 3), matrix_trans(1, 3), matrix_trans(2, 3));
    // printf("guess_pose Rotation matrix :\n");
    // printf("    | %f %f %f | \n", init_guess(0, 0), guess_pose(0, 1), guess_pose(0, 2));
    // printf("R = | %f %f %f | \n", init_guess(1, 0), guess_pose(1, 1), guess_pose(1, 2));
    // printf("    | %f %f %f | \n", guess_pose(2, 0), guess_pose(2, 1), guess_pose(2, 2));
    // printf("guess_pose Translation vector :\n");
    // printf("t = < %f, %f, %f >\n\n", guess_pose(0, 3), guess_pose(1, 3), guess_pose(2, 3));

    cudaFree(PUVM);
    cudaFree(QUVM);
    cudaFree(cudaMatrix);
    cudaFree(guess);

    // auto cloudSrc = input_source;
    // auto cloudDst = result_cloud_ptr;
    // pcl::PointCloud<pcl::PointXYZ> input_transformed;
    // pcl::transformPointCloud (*cloudSrc, input_transformed, matrix_trans);

    // pcl::PointCloud<pcl::PointXYZRGB>::Ptr cloudSrcRGB (new pcl::PointCloud<pcl::PointXYZRGB>(cloudSrc->size(),1));
    // pcl::PointCloud<pcl::PointXYZRGB>::Ptr cloudDstRGB (new pcl::PointCloud<pcl::PointXYZRGB>(cloudDst->size(),1));
    // pcl::PointCloud<pcl::PointXYZRGB>::Ptr cloudALL (new pcl::PointCloud<pcl::PointXYZRGB>(cloudSrc->size() + cloudDst->size(),1));
    // // Fill in the CloudIn data
    // for (int i = 0; i < cloudSrc->size(); i++)
    // {
    //   pcl::PointXYZRGB &pointin = (*cloudSrcRGB)[i];
    //   pointin.x = (input_transformed)[i].x;
    //   pointin.y = (input_transformed)[i].y;
    //   pointin.z = (input_transformed)[i].z;
    //   pointin.r = 255;
    //   pointin.g = 0;
    //   pointin.b = 0;
    //   (*cloudALL)[i] = pointin;
    // }
    // for (int i = 0; i < cloudDst->size(); i++)
    // {
    //   pcl::PointXYZRGB &pointout = (*cloudDstRGB)[i];
    //   pointout.x = (*cloudDst)[i].x;
    //   pointout.y = (*cloudDst)[i].y;
    //   pointout.z = (*cloudDst)[i].z;
    //   pointout.r = 0;
    //   pointout.g = 255;
    //   pointout.b = 255;
    //   (*cloudALL)[i+cloudSrc->size()] = pointout;
    // }
    return true;
  }

  double NDTCUDARegistration::calculateFitneeScore(pcl::PointCloud<pcl::PointXYZ>::Ptr P,
        pcl::PointCloud<pcl::PointXYZ>::Ptr Q,
        Eigen::Matrix4f transformation_matrix)
  {
    double fitness_score = 0.0;
    pcl::PointCloud<pcl::PointXYZ> input_transformed;
    pcl::transformPointCloud (*P, input_transformed, transformation_matrix);

    pcl::search::KdTree<pcl::PointXYZ> tree_;
    std::vector<int> nn_indices (1);
    std::vector<float> nn_dists (1);

    tree_.setInputCloud(Q);
    int nr = 0;
    for (std::size_t i = 0; i < input_transformed.points.size (); ++i)
    {
      // Find its nearest neighbor in the target
      tree_.nearestKSearch (input_transformed.points[i], 1, nn_indices, nn_dists);
      if (nn_dists[0] <=  std::numeric_limits<double>::max ())
      {
        // Add to the fitness score
        fitness_score += nn_dists[0];
        nr++;
      }
    }
    if (nr > 0)
      return (fitness_score / nr);
    return (std::numeric_limits<double>::max ());
  }

} // namespace  robot_localization

#endif