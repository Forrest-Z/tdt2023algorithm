/*
 * @Description: context匹配工作节点
 */
#include <rclcpp/rclcpp.hpp>
#include "glog/logging.h"
#include "robot_pre_slam/global_path_defination/global_path.h"
// #include "../include/global_path_defination/global_path.h"
#include "localization_interfaces/srv/save_scan_context.hpp"
#include "robot_pre_slam/context_flow.hpp"

using localization_interfaces::srv::SaveScanContext;

using namespace robot_pre_slam;

bool save_scan_context = false;

bool SaveScanContextCb(const std::shared_ptr<SaveScanContext::Request> request, std::shared_ptr<SaveScanContext::Response> response) 
{
    save_scan_context = true;
    response->succeed = true;
    return response->succeed;
}

int main(int argc, char *argv[]) 
{
    google::InitGoogleLogging(argv[0]);
    FLAGS_log_dir = WORK_PACKAGE_PATH + "/Log";
    FLAGS_alsologtostderr = 1;

    rclcpp::init(argc, argv);
    rclcpp::Node::SharedPtr ros2_node = nullptr;
    ros2_node = rclcpp::Node::make_shared("context_match_node");

    // subscribe to:
    // a. key frame pose and corresponding GNSS/IMU pose from backend node
    // publish:
    // a. loop closure detection result for backend node:
    std::shared_ptr<ContextFlow> loop_closing_flow_ptr = std::make_shared<ContextFlow>(ros2_node);

    // register service for scan context save:
    rclcpp::Service<SaveScanContext>::SharedPtr service;
    service = ros2_node->create_service<SaveScanContext>("save_scan_context",SaveScanContextCb); 

    rclcpp::Rate rate(200);
    printf("to ContextFlow loop");

    while (rclcpp::ok()) 
    {
        rclcpp::spin_some(ros2_node);

        loop_closing_flow_ptr->Run();

        if (save_scan_context) 
        {
            save_scan_context = false;
            loop_closing_flow_ptr->Save();
        }

        // rate.sleep();
    }

    return 0;
}