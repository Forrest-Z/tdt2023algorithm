/*
 * @Description: 上下文匹配技术工作流
 */
#include "robot_pre_slam/global_path_defination/global_path.h"
#include "robot_pre_slam/context_flow.hpp"
#include "localization_tools/color_terminal.hpp"
#include "glog/logging.h"

namespace robot_pre_slam {

ContextFlow::ContextFlow(std::shared_ptr<rclcpp::Node> &node_) 
{   
    // subscriber:
    key_scan_sub_ptr_ = std::make_shared<robot_localization::CloudSubscriber>(node_, "/velodyne_points2", 100000);
    key_frame_sub_ptr_ = std::make_shared<robot_localization::KeyFrameSubscriber>(node_, "/fused_odom_frame", 100000);
    key_gnss_sub_ptr_ = std::make_shared<robot_localization::KeyFrameSubscriber>(node_, "/fused_odom_frame", 100000);
    // publisher
    loop_pose_pub_ptr_ = std::make_shared<robot_localization::LoopPosePublisher>(node_, "/loop_pose", "odom", 100);
    // loop closing
    scan_context_ptr_ = std::make_shared<ScanContext>();
    robot_localization::green_info("ContextFlow init done");
}

bool ContextFlow::Run() 
{
    if (!ReadData())
        return false;
    // robot_localization::green_info("ReadData done");
    printf("key_gnss_buff_:%d\n",key_gnss_buff_.size());
    printf("key_scan_buff_:%d\n",key_scan_buff_.size());
    while(HasData()) 
    {    robot_localization::green_info("to start");

        if (!ValidData())
            continue;
        
        scan_context_ptr_->Update(current_key_scan_, current_key_frame_, current_key_gnss_);
        
        PublishData();
    }

    return true;
}

bool ContextFlow::Save(void) 
{
    return scan_context_ptr_->Save();
}

bool ContextFlow::ReadData() 
{
    key_scan_sub_ptr_->ParseData(key_scan_buff_);
    key_frame_sub_ptr_->ParseData(key_frame_buff_);
    key_gnss_sub_ptr_->ParseData(key_gnss_buff_);

    return true;
}

bool ContextFlow::HasData() 
{
    if( key_scan_buff_.size()  == 0 ||
        key_frame_buff_.size() == 0 ||
        key_gnss_buff_.size()  == 0
      ) 
    {
        return false;
    }

    return true;
}

bool ContextFlow::ValidData() 
{
    current_key_scan_ = key_scan_buff_.front();
    current_key_frame_ = key_frame_buff_.front();
    current_key_gnss_ = key_gnss_buff_.front();

    double diff_gnss_time = current_key_frame_.time - current_key_gnss_.time;

    if (diff_gnss_time < -0.04) 
    {
        key_frame_buff_.pop_front();
        return false;
    }

    if (diff_gnss_time > 0.04) 
    {
        key_gnss_buff_.pop_front();
        return false;
    }

    key_scan_buff_.pop_front();
    key_frame_buff_.pop_front();
    key_gnss_buff_.pop_front();

    return true;
}

bool ContextFlow::PublishData() 
{
    if (scan_context_ptr_->HasNewLoopPose()) 
        loop_pose_pub_ptr_->Publish(scan_context_ptr_->GetCurrentLoopPose());

    return true;
}
}