import os
from launch import LaunchDescription
from launch_ros.actions import Node
from launch.actions import IncludeLaunchDescription
from launch.launch_description_sources import PythonLaunchDescriptionSource
from ament_index_python.packages import get_package_share_directory
from launch_ros.substitutions import FindPackageShare
from launch.actions import DeclareLaunchArgument
from launch.launch_description_sources import PythonLaunchDescriptionSource
from launch.substitutions import LaunchConfiguration

def generate_launch_description():
    ld = LaunchDescription()
    context_match_node = Node(
                                package="robot_pre_slam",
                                executable='context_match_node',
                                output='screen',emulate_tty=True,
                                parameters=[{'use_sim_time': True}]
                              )
    
    
    # ld.add_action(graph_optimizing_end_node)
    ld.add_action(context_match_node)

    return ld