/*
 * @Description: 上下文匹配技术接口
 */
#ifndef PRE_SLAM_CONTEXT_FLOW_HPP_
#define PRE_SLAM_CONTEXT_FLOW_HPP_

#include <deque>
#include "rclcpp/rclcpp.hpp"
// subscriber
#include "robot_localization/subscriber/cloud_subscriber.hpp"
#include "robot_localization/subscriber/key_frame_subscriber.hpp"
// publisher
#include "robot_localization/publisher/loop_pose_publisher.hpp"
// loop closing
#include "scan_context.hpp"

namespace robot_pre_slam {
class ContextFlow 
{
  public:
    ContextFlow(std::shared_ptr<rclcpp::Node> &node_);

    bool Run();
    bool Save();
    
  private:
    bool ReadData();
    bool HasData();
    bool ValidData();
    bool PublishData();

  private:
    // subscriber
    std::shared_ptr<robot_localization::CloudSubscriber> key_scan_sub_ptr_;
    std::shared_ptr<robot_localization::KeyFrameSubscriber> key_frame_sub_ptr_;
    std::shared_ptr<robot_localization::KeyFrameSubscriber> key_gnss_sub_ptr_;
    // publisher
    std::shared_ptr<robot_localization::LoopPosePublisher> loop_pose_pub_ptr_;
    // loop closing
    std::shared_ptr<ScanContext> scan_context_ptr_;

    std::deque<robot_localization::CloudData> key_scan_buff_;
    std::deque<robot_localization::KeyFrame> key_frame_buff_;
    std::deque<robot_localization::KeyFrame> key_gnss_buff_;

    robot_localization::CloudData current_key_scan_;
    robot_localization::KeyFrame current_key_frame_;
    robot_localization::KeyFrame current_key_gnss_;
};
}

#endif