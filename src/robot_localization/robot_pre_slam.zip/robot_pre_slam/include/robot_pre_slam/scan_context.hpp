/*
 * @Description: scan_context闭环检测算法
 */
#ifndef PRE_SLAM_SCAN_CONTEXT_HPP_
#define PRE_SLAM_SCAN_CONTEXT_HPP_

#include <cmath>
#include <algorithm>
#include <limits>

#include <pcl/common/transforms.h>
#include <pcl/io/pcd_io.h>

#include <deque>
#include <Eigen/Dense>
#include <pcl/registration/ndt.h>
#include <yaml-cpp/yaml.h>

#include "sensor_data/key_frame.hpp"
#include "sensor_data/pose_data.hpp"
#include "sensor_data/loop_frame_pose.hpp"
#include "localization_models/cloud_filter/cloud_filter_interface.hpp"
#include "localization_models/cloud_filter/box_filter.hpp"
#include "localization_models/cloud_filter/voxel_filter.hpp"
#include "localization_models/cloud_filter/no_filter.hpp"
#include "localization_models/registration/registration_interface.hpp"
#include "localization_models/registration/icp_registration.hpp"
#include "localization_models/registration/icp_svd_registration.hpp"
#include "localization_models/registration/ndt_cpu/ndt_cpu_registration.hpp"
// #include "localization_models/registration/ndt_cuda/ndt_cuda_registration.hpp"
#include "localization_models/registration/ndt_registration.hpp"
#include "localization_models/registration/sicp/scip_registration.hpp"

#include "robot_localization/models/scan_context_manager/scan_context_manager.hpp"


#include "global_path_defination/global_path.h"

namespace robot_pre_slam {
class ScanContext {
  public:
    ScanContext();

    bool Update(
      const robot_localization::CloudData &key_scan, 
      const robot_localization::KeyFrame &key_frame, 
      const robot_localization::KeyFrame &key_gnss
    );

    bool HasNewLoopPose();
    robot_localization::LoopPose& GetCurrentLoopPose();

    bool Save(void);

  private:
    bool InitWithConfig();
    bool InitParam(const YAML::Node& config_node);
    bool InitDataPath(const YAML::Node& config_node);
    bool InitFilter(std::string filter_user, std::shared_ptr<robot_localization::CloudFilterInterface>& filter_ptr, const YAML::Node& config_node);
    bool InitLoopClosure(const YAML::Node& config_node);
    bool InitRegistration(std::shared_ptr<robot_localization::RegistrationInterface>& registration_ptr, const YAML::Node& config_node);
    
    bool DetectNearestKeyFrame(
      int& key_frame_index,
      float& yaw_change_in_rad
    );
    bool CloudRegistration(
      const int key_frame_index,
      const float yaw_change_in_rad
    );
    bool JointMap(
      const int key_frame_index, const float yaw_change_in_rad,
      robot_localization::CloudData::CLOUD_PTR& map_cloud_ptr, Eigen::Matrix4f& map_pose
    );
    bool JointScan(robot_localization::CloudData::CLOUD_PTR& scan_cloud_ptr, Eigen::Matrix4f& scan_pose);
    bool Registration(robot_localization::CloudData::CLOUD_PTR& map_cloud_ptr, 
                      robot_localization::CloudData::CLOUD_PTR& scan_cloud_ptr, 
                      Eigen::Matrix4d& scan_pose, 
                      Eigen::Matrix4d& result_pose);

  private:
    std::string key_frames_path_ = "";
    std::string scan_context_path_ = "";

    std::string loop_closure_method_ = "";

    int extend_frame_num_ = 3;
    int loop_step_ = 10;
    int diff_num_ = 100;
    float detect_area_ = 10.0;
    float fitness_score_limit_ = 2.0;

    std::shared_ptr<robot_localization::CloudFilterInterface> scan_filter_ptr_;
    std::shared_ptr<robot_localization::CloudFilterInterface> map_filter_ptr_;
    std::shared_ptr<robot_localization::ScanContextManager> scan_context_manager_ptr_;
    std::shared_ptr<robot_localization::RegistrationInterface> registration_ptr_; 

    std::deque<robot_localization::KeyFrame> all_key_frames_;
    std::deque<robot_localization::KeyFrame> all_key_gnss_;

    robot_localization::LoopPose current_loop_pose_;
    bool has_new_loop_pose_ = false;
};
}

#endif